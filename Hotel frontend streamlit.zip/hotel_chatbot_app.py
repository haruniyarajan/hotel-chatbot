"""
Hotel Customer Service Chatbot - Streamlit Frontend
A beautiful, interactive web interface for the hotel chatbot

Run with: streamlit run hotel_chatbot_app.py
"""

import streamlit as st
import sys
import os
import json
from datetime import datetime
from pathlib import Path

# Add parent directory to path to import chatbot
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import the chatbot
try:
    from hotel_chatbot_with_rag_eval import EnhancedHotelChatbot, QueryIntent
except ImportError:
    st.error("⚠️ Could not import hotel chatbot. Make sure hotel_chatbot_with_rag_eval.py is in the same directory.")
    st.stop()

# Page configuration
st.set_page_config(
    page_title="Hotel AI Assistant",
    page_icon="🏨",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .main-header {
        font-size: 3rem;
        font-weight: bold;
        text-align: center;
        color: #1f77b4;
        margin-bottom: 1rem;
    }
    .sub-header {
        text-align: center;
        color: #666;
        margin-bottom: 2rem;
    }
    .chat-message {
        padding: 1rem;
        border-radius: 10px;
        margin-bottom: 1rem;
        border: 1px solid #e0e0e0;
    }
    .user-message {
        background-color: #e3f2fd;
        border-left: 4px solid #2196f3;
    }
    .bot-message {
        background-color: #f5f5f5;
        border-left: 4px solid #4caf50;
    }
    .metric-card {
        background-color: #f8f9fa;
        padding: 1rem;
        border-radius: 8px;
        border: 1px solid #dee2e6;
    }
    .stButton>button {
        width: 100%;
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state
if 'chatbot' not in st.session_state:
    with st.spinner('🔄 Initializing AI Assistant...'):
        st.session_state.chatbot = EnhancedHotelChatbot(use_kaggle_data=True)
    st.session_state.chat_history = []
    st.session_state.session_id = f"session_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    st.session_state.message_count = 0

# Sidebar
with st.sidebar:
    st.image("https://via.placeholder.com/300x100/1f77b4/ffffff?text=Hotel+AI", use_column_width=True)
    
    st.markdown("## 🎯 Quick Actions")
    
    if st.button("🗑️ Clear Chat History"):
        st.session_state.chat_history = []
        st.session_state.message_count = 0
        st.rerun()
    
    if st.button("📊 View Performance Metrics"):
        st.session_state.show_metrics = not st.session_state.get('show_metrics', False)
        st.rerun()
    
    if st.button("💾 Export Conversation"):
        if st.session_state.chat_history:
            st.session_state.chatbot.save_conversation_history(f"chat_{st.session_state.session_id}.json")
            st.success("✅ Conversation exported!")
        else:
            st.warning("⚠️ No conversation to export")
    
    st.markdown("---")
    st.markdown("## 📋 Sample Questions")
    
    sample_questions = [
        "What time is check-in?",
        "Do you allow pets?",
        "What amenities do you offer?",
        "I need to cancel my booking",
        "What are your room rates?",
        "Is there free WiFi?",
    ]
    
    for question in sample_questions:
        if st.button(f"💬 {question}", key=f"sample_{question}"):
            st.session_state.pending_question = question
            st.rerun()
    
    st.markdown("---")
    st.markdown("## ℹ️ About")
    st.info("""
    **Hotel AI Assistant**
    
    Powered by:
    - 🤖 GPT-3.5 Turbo
    - 🧠 Machine Learning
    - 📊 RAG Architecture
    - 🎯 Intent Recognition
    
    Features:
    - Real-time responses
    - Context awareness
    - Multi-turn conversations
    - Performance tracking
    """)
    
    st.markdown("---")
    st.markdown("### 🔧 Settings")
    
    enable_rag_eval = st.checkbox("Enable RAG Evaluation", value=False, 
                                  help="Track quality metrics for responses")
    
    show_intent = st.checkbox("Show Intent Recognition", value=False,
                              help="Display detected intent and entities")

# Main content
st.markdown('<h1 class="main-header">🏨 Hotel AI Assistant</h1>', unsafe_allow_html=True)
st.markdown('<p class="sub-header">Your 24/7 intelligent hotel concierge</p>', unsafe_allow_html=True)

# Show metrics if requested
if st.session_state.get('show_metrics', False):
    st.markdown("## 📊 Performance Metrics")
    
    metrics = st.session_state.chatbot.get_real_performance_metrics()
    
    if "error" not in metrics:
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric(
                label="📝 Total Queries",
                value=metrics.get('total_queries', 0)
            )
        
        with col2:
            st.metric(
                label="⚡ Response Time",
                value=f"{metrics.get('average_response_time', 0):.2f}s",
                delta=f"-{metrics.get('response_time_reduction_actual', 0):.1f}%"
            )
        
        with col3:
            st.metric(
                label="✅ Resolution Rate",
                value=f"{metrics.get('query_resolution_accuracy_actual', 0):.1f}%"
            )
        
        with col4:
            st.metric(
                label="🎯 Avg Confidence",
                value=f"{metrics.get('average_confidence', 0):.2f}"
            )
        
        st.markdown("---")

# Chat interface
st.markdown("## 💬 Chat")

# Display chat history
chat_container = st.container()
with chat_container:
    for message in st.session_state.chat_history:
        if message['role'] == 'user':
            st.markdown(f"""
            <div class="chat-message user-message">
                <strong>👤 You:</strong><br>
                {message['content']}
            </div>
            """, unsafe_allow_html=True)
        else:
            st.markdown(f"""
            <div class="chat-message bot-message">
                <strong>🤖 AI Assistant:</strong><br>
                {message['content']}
            </div>
            """, unsafe_allow_html=True)
            
            # Show intent if enabled
            if show_intent and 'metadata' in message:
                with st.expander("🔍 Technical Details"):
                    col1, col2 = st.columns(2)
                    with col1:
                        st.write("**Intent:**", message['metadata'].get('intent', 'N/A'))
                        st.write("**Confidence:**", f"{message['metadata'].get('confidence', 0):.2%}")
                    with col2:
                        st.write("**Entities:**", message['metadata'].get('entities', {}))
                        st.write("**Response Time:**", f"{message['metadata'].get('response_time', 0):.2f}s")

# Handle pending question from sidebar
if 'pending_question' in st.session_state:
    user_input = st.session_state.pending_question
    del st.session_state.pending_question
else:
    user_input = None

# Chat input
with st.container():
    col1, col2 = st.columns([6, 1])
    
    with col1:
        user_message = st.chat_input("Type your message here...", key="chat_input")
    
    with col2:
        send_button = st.button("📤 Send", type="primary")

# Process message
if user_message or user_input:
    message_to_process = user_message if user_message else user_input
    
    # Add user message to history
    st.session_state.chat_history.append({
        'role': 'user',
        'content': message_to_process,
        'timestamp': datetime.now().isoformat()
    })
    
    # Show thinking indicator
    with st.spinner('🤔 AI is thinking...'):
        # Get response from chatbot
        response = st.session_state.chatbot.process_query(
            message_to_process,
            session_id=st.session_state.session_id,
            evaluate_rag=enable_rag_eval
        )
        
        # Get the last query for metadata
        if st.session_state.chatbot.queries:
            last_query = st.session_state.chatbot.queries[-1]
            metadata = {
                'intent': last_query.intent.value,
                'confidence': last_query.confidence_score,
                'entities': last_query.entities,
                'response_time': last_query.response_time,
                'resolved': last_query.resolved
            }
        else:
            metadata = {}
        
        # Add bot response to history
        st.session_state.chat_history.append({
            'role': 'bot',
            'content': response,
            'timestamp': datetime.now().isoformat(),
            'metadata': metadata
        })
        
        st.session_state.message_count += 1
    
    # Rerun to display new messages
    st.rerun()

# Empty state
if not st.session_state.chat_history:
    st.markdown("""
    <div style='text-align: center; padding: 3rem; color: #999;'>
        <h3>👋 Welcome to Hotel AI Assistant!</h3>
        <p>Ask me anything about our hotel services:</p>
        <ul style='list-style: none; padding: 0;'>
            <li>🏨 Room bookings and availability</li>
            <li>⏰ Check-in and check-out times</li>
            <li>🎯 Hotel amenities and services</li>
            <li>💰 Pricing and packages</li>
            <li>🐕 Pet policies</li>
            <li>❓ Any other questions!</li>
        </ul>
        <p><em>Click a sample question in the sidebar or type your own below.</em></p>
    </div>
    """, unsafe_allow_html=True)

# Footer
st.markdown("---")
col1, col2, col3 = st.columns(3)

with col1:
    st.markdown("### 📞 Contact")
    st.markdown("""
    **Hotel Support**  
    📧 support@hotel.com  
    📱 +1 (555) 123-4567
    """)

with col2:
    st.markdown("### 🕒 Hours")
    st.markdown("""
    **AI Assistant:** 24/7  
    **Front Desk:** 8am - 10pm  
    **Concierge:** 9am - 8pm
    """)

with col3:
    st.markdown("### 📊 Session Info")
    st.markdown(f"""
    **Messages:** {st.session_state.message_count}  
    **Session ID:** {st.session_state.session_id[:12]}...  
    **Status:** 🟢 Active
    """)

# Debug section (hidden by default)
with st.expander("🔧 Developer Tools"):
    st.markdown("### 🐛 Debug Information")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("**Chatbot Status:**")
        st.json({
            "llm_initialized": st.session_state.chatbot.llm is not None,
            "rag_chain_ready": st.session_state.chatbot.rag_chain is not None,
            "total_queries": len(st.session_state.chatbot.queries),
            "evaluations": len(st.session_state.chatbot.rag_evaluations)
        })
    
    with col2:
        st.write("**Session State:**")
        st.json({
            "session_id": st.session_state.session_id,
            "message_count": st.session_state.message_count,
            "chat_history_length": len(st.session_state.chat_history),
        })
    
    if st.button("🧪 Run Stress Test"):
        with st.spinner("Running stress test with 10 queries..."):
            st.session_state.chatbot.stress_test(10)
        st.success("✅ Stress test complete! Check console for results.")
    
    if st.button("📈 Show Detailed Metrics"):
        st.session_state.chatbot.print_detailed_metrics()
        st.success("✅ Metrics printed to console!")
    
    if enable_rag_eval and st.session_state.chatbot.rag_evaluations:
        if st.button("🔍 Show RAG Evaluation Summary"):
            st.session_state.chatbot.print_rag_evaluation_summary()
            st.success("✅ RAG evaluation printed to console!")
