# 🚀 Hotel Chatbot Streamlit App - Quick Start

## ⚡ Get Started in 3 Minutes!

### Step 1: Install Everything (1 minute)

```bash
# Install dependencies
pip install -r requirements_streamlit.txt

# Download spaCy model
python -m spacy download en_core_web_sm
```

### Step 2: Set Up API Key (30 seconds)

Create a `.env` file:

```bash
echo "OPENAI_API_KEY=your_openai_api_key_here" > .env
```

### Step 3: Run the App! (30 seconds)

```bash
streamlit run hotel_chatbot_app.py
```

**That's it!** Your browser will open at `http://localhost:8501`

---

## 🎯 What You'll See

### Beautiful Chat Interface
```
┌─────────────────────────────────────────┐
│  🏨 Hotel AI Assistant                  │
│  Your 24/7 intelligent hotel concierge  │
├─────────────────────────────────────────┤
│                                         │
│  👤 You: What time is check-in?        │
│                                         │
│  🤖 Bot: Check-in time is 3:00 PM...   │
│                                         │
│  [Type your message here...]  [Send]   │
└─────────────────────────────────────────┘
```

### Sidebar Features
- 🗑️ Clear chat
- 📊 View metrics
- 💾 Export conversation
- 💬 Sample questions (click to try!)

---

## 💡 Try These First!

Click these sample questions in the sidebar:
1. "What time is check-in?"
2. "Do you allow pets?"
3. "What amenities do you offer?"
4. "What are your room rates?"

---

## 📊 Cool Features

### 1. Performance Metrics
Click "📊 View Performance Metrics" to see:
- Total queries processed
- Average response time
- Resolution accuracy
- Confidence scores

### 2. Intent Recognition
Enable "Show Intent Recognition" in settings to see:
- What the AI understood
- Confidence level
- Extracted entities
- Response time

### 3. Export Chat
Click "💾 Export Conversation" to save your chat history to JSON

---

## 🎨 App Layout

```
┌──────────────────────────────────────────────────────┐
│                  Main Header                         │
├───────────────┬──────────────────────────────────────┤
│   SIDEBAR     │         CHAT AREA                    │
│               │                                      │
│ 🎯 Actions    │  Chat History                       │
│ 📋 Samples    │  ...messages...                     │
│ ℹ️ About      │                                      │
│ 🔧 Settings   │  [Type message...] [Send]           │
└───────────────┴──────────────────────────────────────┘
```

---

## 🐛 Common Issues & Fixes

### Issue: "Could not import hotel chatbot"
**Fix:** Make sure these files are in the same directory:
- `hotel_chatbot_app.py`
- `hotel_chatbot_with_rag_eval.py`

### Issue: "LLM initialization failed"
**Fix:** Check your `.env` file has valid OpenAI API key

### Issue: App is slow
**Fix:** 
- Check internet connection
- Disable RAG evaluation in settings
- Verify OpenAI API is working

---

## 📱 Mobile Access

Want to access on your phone?

1. Find your computer's IP address:
   ```bash
   # Windows
   ipconfig
   
   # Mac/Linux
   ifconfig
   ```

2. Run with external URL:
   ```bash
   streamlit run hotel_chatbot_app.py --server.address 0.0.0.0
   ```

3. Access from phone:
   ```
   http://YOUR_IP:8501
   ```

---

## 🎮 Play Around!

### Try Multi-turn Conversations:
```
You: "I need a room"
Bot: "What dates are you considering?"
You: "Next Friday"
Bot: "For how many guests?"
You: "Two people"
Bot: [provides options]
```

### Test Different Queries:
- Bookings
- Cancellations
- Amenities
- Pricing
- Policies
- General info

---

## 🔧 Customize It!

### Change Colors
Create `.streamlit/config.toml`:
```toml
[theme]
primaryColor = "#ff6b6b"  # Change this!
backgroundColor = "#ffffff"
```

### Add More Sample Questions
Edit `hotel_chatbot_app.py`:
```python
sample_questions = [
    "Your question here",
    # Add more...
]
```

---

## 📊 Monitor Performance

Enable metrics to track:
- How many queries processed
- Average response time
- Success rate
- Confidence levels

Perfect for:
- Demonstrations
- Testing
- Performance analysis
- Showcasing to stakeholders

---

## 🚀 Next Steps

1. **Try all sample questions**
2. **Enable RAG evaluation** in settings
3. **Export a conversation** to see the JSON
4. **Run the stress test** in developer tools
5. **Show it to friends/colleagues!**

---

## 💻 File Checklist

Make sure you have:
- ✅ `hotel_chatbot_app.py` - Main Streamlit app
- ✅ `hotel_chatbot_with_rag_eval.py` - Backend chatbot
- ✅ `requirements_streamlit.txt` - Dependencies
- ✅ `.env` - Your OpenAI API key

---

## 🎉 Success!

If you see the chat interface with the hotel logo, you're ready to go!

**Tips:**
- Start with sample questions
- Try natural conversations
- Check the metrics dashboard
- Explore developer tools
- Have fun! 🎈

---

## 📚 Learn More

- **Full Documentation:** See STREAMLIT_README.md
- **Backend Code:** See hotel_chatbot_with_rag_eval.py
- **Streamlit Docs:** https://docs.streamlit.io

---

**Questions? Issues? Check the troubleshooting section in STREAMLIT_README.md!**

🌟 **Enjoy your AI-powered hotel assistant!** 🌟
