# Hotel Chatbot - Streamlit Web App

A beautiful, interactive web interface for the Hotel Customer Service Chatbot.

![Streamlit](https://img.shields.io/badge/Streamlit-FF4B4B?style=for-the-badge&logo=Streamlit&logoColor=white)
![Python](https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white)
![OpenAI](https://img.shields.io/badge/OpenAI-412991?style=for-the-badge&logo=openai&logoColor=white)

## 🌟 Features

- **💬 Interactive Chat Interface** - Beautiful, responsive chat UI
- **🎯 Intent Recognition Display** - See how AI understands your queries
- **📊 Real-time Performance Metrics** - Track response times and accuracy
- **🔍 RAG Evaluation** - Optional quality metrics for responses
- **💾 Export Conversations** - Save chat history to JSON
- **📱 Mobile Responsive** - Works on all devices
- **🎨 Modern UI** - Clean, professional design
- **⚡ Real-time Updates** - Instant responses

## 📋 Prerequisites

- Python 3.8 or higher
- OpenAI API key
- spaCy English model

## 🚀 Quick Start

### 1. Install Dependencies

```bash
pip install -r requirements_streamlit.txt
```

### 2. Download spaCy Model

```bash
python -m spacy download en_core_web_sm
```

### 3. Set Up Environment

Create a `.env` file:

```bash
OPENAI_API_KEY=your_openai_api_key_here
```

### 4. Run the App

```bash
streamlit run hotel_chatbot_app.py
```

The app will open in your browser at `http://localhost:8501`

## 🎨 Interface Overview

### Main Chat Area
- **Chat History** - All conversations displayed with timestamps
- **User Messages** - Blue background with user icon
- **Bot Messages** - Gray background with bot icon
- **Chat Input** - Type your message at the bottom

### Sidebar Features

#### 🎯 Quick Actions
- **Clear Chat History** - Start a new conversation
- **View Performance Metrics** - See chatbot statistics
- **Export Conversation** - Save to JSON file

#### 📋 Sample Questions
Pre-made questions you can click to try:
- "What time is check-in?"
- "Do you allow pets?"
- "What amenities do you offer?"
- "I need to cancel my booking"
- "What are your room rates?"
- "Is there free WiFi?"

#### ℹ️ About Section
Information about the AI assistant and its capabilities

#### 🔧 Settings
- **Enable RAG Evaluation** - Track quality metrics
- **Show Intent Recognition** - Display technical details

## 📊 Performance Metrics

When enabled, the app shows:

- **📝 Total Queries** - Number of messages processed
- **⚡ Response Time** - Average response time with improvement percentage
- **✅ Resolution Rate** - Percentage of successfully resolved queries
- **🎯 Avg Confidence** - Average confidence score of responses

## 🔧 Advanced Features

### Developer Tools (Expand at bottom)

**Debug Information:**
- Chatbot initialization status
- Session state information
- Query statistics

**Testing Tools:**
- **Run Stress Test** - Test with 10 queries
- **Show Detailed Metrics** - Full performance analysis
- **Show RAG Evaluation** - Quality metrics summary

### RAG Evaluation Mode

Enable in settings to track:
- Faithfulness scores
- Answer relevancy
- Context precision
- Context recall
- Answer correctness

## 💡 Usage Tips

### Getting Started
1. Click a sample question from sidebar
2. Or type your own question
3. AI responds in real-time
4. Continue the conversation naturally

### Best Questions to Ask
- **Bookings:** "I want to book a room for Friday"
- **Amenities:** "What facilities do you have?"
- **Policies:** "What's your cancellation policy?"
- **Services:** "Do you have room service?"
- **Pricing:** "How much for a deluxe suite?"

### Multi-turn Conversations
The chatbot remembers context:
```
You: "I need a room"
Bot: "I'd be happy to help! What dates are you considering?"
You: "Next weekend"
Bot: "Great! For how many guests?"
You: "Two adults"
Bot: "Perfect! Let me check availability..."
```

## 🎨 Customization

### Change Theme

Create `.streamlit/config.toml`:

```toml
[theme]
primaryColor = "#1f77b4"
backgroundColor = "#ffffff"
secondaryBackgroundColor = "#f0f2f6"
textColor = "#262730"
font = "sans serif"
```

### Modify Sample Questions

Edit in `hotel_chatbot_app.py`:

```python
sample_questions = [
    "Your custom question 1",
    "Your custom question 2",
    # Add more...
]
```

### Customize Header Image

Replace placeholder URL in sidebar:

```python
st.image("your_hotel_logo.png", use_column_width=True)
```

## 📱 Mobile Experience

The app is fully responsive:
- Touch-friendly buttons
- Optimized layout
- Smooth scrolling
- Mobile keyboard support

## 🐛 Troubleshooting

### "Could not import hotel chatbot"
**Solution:** Make sure `hotel_chatbot_with_rag_eval.py` is in the same directory

### "LLM initialization failed"
**Solution:** Check your `.env` file has valid `OPENAI_API_KEY`

### "spaCy model not found"
**Solution:** Run `python -m spacy download en_core_web_sm`

### App is slow
**Solutions:**
- Check internet connection
- Verify OpenAI API is responding
- Disable RAG evaluation for faster responses

### Chat history not showing
**Solution:** Refresh the page or clear browser cache

## 📊 Performance Optimization

### For Faster Responses:
1. Disable RAG evaluation in settings
2. Use smaller context window (modify in code)
3. Cache frequently asked questions

### For Better Accuracy:
1. Enable RAG evaluation
2. Show intent recognition to verify understanding
3. Provide feedback on responses

## 🔒 Security Notes

- Never commit `.env` file to version control
- Keep OpenAI API key secure
- Clear sensitive conversations before sharing
- Use environment variables for production

## 📁 File Structure

```
hotel-chatbot-streamlit/
│
├── hotel_chatbot_app.py              # Main Streamlit app
├── hotel_chatbot_with_rag_eval.py    # Backend chatbot
├── requirements_streamlit.txt         # Dependencies
├── .env                               # API keys (create this)
│
├── .streamlit/                        # Optional config
│   └── config.toml                    # Theme settings
│
└── exports/                           # Saved conversations
    └── chat_*.json                    # Exported chats
```

## 🚀 Deployment

### Deploy to Streamlit Cloud

1. Push code to GitHub
2. Go to [share.streamlit.io](https://share.streamlit.io)
3. Connect your repository
4. Add secrets (OpenAI API key)
5. Deploy!

### Deploy with Docker

```dockerfile
FROM python:3.9-slim

WORKDIR /app

COPY requirements_streamlit.txt .
RUN pip install -r requirements_streamlit.txt
RUN python -m spacy download en_core_web_sm

COPY . .

EXPOSE 8501

CMD ["streamlit", "run", "hotel_chatbot_app.py"]
```

Build and run:
```bash
docker build -t hotel-chatbot .
docker run -p 8501:8501 -e OPENAI_API_KEY=your_key hotel-chatbot
```

## 💬 Features Showcase

### Chat Interface
```
👤 You: What time is check-in?

🤖 AI Assistant: Check-in time is 3:00 PM and 
check-out time is 11:00 AM. We can accommodate 
early check-in or late check-out based on availability. 
Would you like to request either?

🔍 Technical Details:
Intent: check_in_out
Confidence: 94.3%
Response Time: 2.34s
```

### Performance Dashboard
```
📝 Total Queries        ⚡ Response Time
    42                     2.3s (-84.7%)

✅ Resolution Rate      🎯 Avg Confidence
    91.2%                  0.87
```

## 🎓 Learning Resources

### Understand the Code
- `st.chat_input()` - Chat input widget
- `st.spinner()` - Loading indicator
- `st.session_state` - Persistent state
- `st.rerun()` - Refresh app
- Custom CSS with `st.markdown()`

### Extend the App
- Add more metrics
- Create visualizations
- Add user authentication
- Implement feedback system
- Add language translation

## 📝 Changelog

### v1.0.0 (Current)
- ✅ Initial release
- ✅ Chat interface
- ✅ Performance metrics
- ✅ Sample questions
- ✅ Export functionality
- ✅ Developer tools
- ✅ RAG evaluation
- ✅ Mobile responsive

## 🤝 Contributing

Ideas for improvements:
- [ ] Chat history search
- [ ] Message reactions
- [ ] Voice input
- [ ] Multi-language support
- [ ] Analytics dashboard
- [ ] Admin panel
- [ ] User preferences
- [ ] Dark mode

## 📄 License

MIT License - Feel free to use for your projects!

## 🙏 Acknowledgments

- **Streamlit** - Amazing web framework
- **OpenAI** - GPT-3.5 Turbo API
- **LangChain** - RAG framework
- **spaCy** - NLP processing

## 📞 Support

Need help?
- 📧 Check the troubleshooting section
- 💬 Open an issue on GitHub
- 📚 Read Streamlit docs: [docs.streamlit.io](https://docs.streamlit.io)

---

**Built with ❤️ for better customer service experiences**

🌟 Star the repo if you find it useful!
